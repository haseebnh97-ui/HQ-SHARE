HQ Share prototype.
Open index.html through an HTTPS static host. Open the same page on two phones.
Receiver creates a code; sender enters it, selects a file, and sends.
This is a prototype using PeerJS/WebRTC, not a full Zapya replacement.
